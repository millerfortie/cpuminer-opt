void x22i_hash(const char* input, char* output);
