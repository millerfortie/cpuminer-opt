uint32_t be32dec(const void *pp);
void be32enc(void *pp, uint32_t x);
uint32_t le32dec(const void *pp);
void le32enc(void *pp, uint32_t x);
